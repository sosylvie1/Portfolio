

<?php $__env->startSection('title', 'Dashboard utilisateur'); ?>
<?php $__env->startSection('robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-white shadow rounded-lg p-6 w-full lg:w-2/3">
        <h2 class="text-xl font-bold mb-2"> Bienvenue <?php echo e(Auth::user()->name); ?> </h2>
        <p class="text-gray-700">
            Je suis ravie de vous retrouver ici dans votre espace personnel.
            Depuis ce tableau de bord, vous pouvez consulter vos <strong>messages</strong>,
            gérer <strong>votre profil</strong> et accéder à mon <strong>CV</strong>.
        </p>
        <p class="mt-4 italic text-gray-600">
            🐟 — <strong>Sylvie </strong>
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/user/dashboard.blade.php ENDPATH**/ ?>