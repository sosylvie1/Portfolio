<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'p' => [
        'title' => '',
        'description' => '',
        'image' => null,
        'tech' => [],
        'github' => null,
        'live' => null,
        'case' => null,
        'readme' => null,
        'video' => null,
        'video_webm' => null,
        'figma' => null,
        'figma_images' => [],
    ],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'p' => [
        'title' => '',
        'description' => '',
        'image' => null,
        'tech' => [],
        'github' => null,
        'live' => null,
        'case' => null,
        'readme' => null,
        'video' => null,
        'video_webm' => null,
        'figma' => null,
        'figma_images' => [],
    ],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    if ($p instanceof \App\Models\Project) {
        $p = $p->toArray();
    }

    $figmaImages = $p['figma_images'] ?? [];
    $techs = $p['tech'] ?? [];

    $imagePath = $p['image'] ?? null;
    $publicPath = $imagePath ? public_path($imagePath) : null;
    $src = $publicPath && file_exists($publicPath) ? asset($imagePath) : asset('images/placeholder.webp');

    $title = $p['title'] ?? '';
    $description = $p['description'] ?? '';
    $techString = implode(' ', $techs);

    $github = $p['github'] ?? null;
    $live = $p['live'] ?? null;
    $readme = $p['readme'] ?? null;

    // ✅ Gestion vidéos (string ou array)
    $videos = [];
    if (!empty($p['video'])) {
        $videos[] = asset($p['video']);
    }
    if (!empty($p['video_webm'])) {
        $videos = is_array($p['video_webm'])
            ? array_map(fn($v) => asset($v), $p['video_webm'])
            : [asset($p['video_webm'])];
    }
?>

<article
    class="group flex flex-col h-full bg-white/80 backdrop-blur border rounded-2xl shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden"
    data-tech="<?php echo e(e($techString)); ?>">

    
    <img src="<?php echo e($src); ?>" alt="<?php echo e($title ? 'Aperçu du projet ' . $title : 'Aperçu du projet'); ?>" loading="lazy"
        decoding="async" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]">

    
    <div class="p-5 flex flex-col gap-4 flex-1">
        <header>
            <h2 class="text-lg sm:text-xl font-semibold leading-tight truncate"><?php echo e($title); ?></h2>
            <?php if($description): ?>
                <p class="mt-2 text-sm text-gray-600 line-clamp-2"><?php echo e($description); ?></p>
            <?php endif; ?>
        </header>

        
        <?php if(!empty($techs)): ?>
            <ul class="flex flex-wrap gap-2" role="list">
                <?php $__currentLoopData = $techs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-[11px] md:text-xs px-2 py-1 rounded-full bg-gray-100 border whitespace-nowrap">
                        <?php echo e($tech); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        
        <div class="mt-auto pt-2 flex flex-wrap gap-2">
            <?php if($github): ?>
                <a href="<?php echo e($github); ?>" target="_blank"
                    class="inline-flex items-center gap-2 text-xs md:text-sm px-3 py-2 rounded-xl border hover:bg-gray-50">
                    Code
                </a>
            <?php endif; ?>
            <?php if($live): ?>
                <a href="<?php echo e($live); ?>" target="_blank"
                    class="inline-flex items-center gap-2 text-xs md:text-sm px-3 py-2 rounded-xl border hover:bg-gray-50">
                    Démo
                </a>
            <?php endif; ?>
            <?php if($readme): ?>
                <a href="<?php echo e($readme); ?>" target="_blank"
                    class="inline-flex items-center gap-2 text-xs md:text-sm px-3 py-2 rounded-xl border hover:bg-gray-50">
                    README
                </a>
            <?php endif; ?>

            
            <?php if(!empty($videos)): ?>
                <div x-data="{ openVideo: false, current: 0, vids: <?php echo \Illuminate\Support\Js::from($videos)->toHtml() ?> }">
                    <button type="button" @click="openVideo = true; current = 0"
                        class="inline-flex items-center gap-2 text-xs md:text-sm px-3 py-2 rounded-xl border hover:bg-gray-50">
                        🎥 Voir la démo
                    </button>
<!-- ✅ Modale Vidéo Plein Écran -->
<div x-show="openVideo" x-transition
     class="fixed inset-0 bg-black/90 flex items-center justify-center z-50"
     style="display:none">
    <div class="relative w-[95%] md:w-[85%] lg:w-[75%]">
        <!-- Bouton fermer -->
        <button @click="
            document.querySelectorAll('#video-player').forEach(v => { v.pause(); v.currentTime = 0; });
            openVideo = false
        "
            class="absolute top-2 right-2 text-white hover:text-gray-300 text-4xl font-bold z-50">✖</button>

        <!-- Vidéo -->
        <video id="video-player" autoplay controls playsinline
               class="w-full max-h-[90vh] rounded-lg shadow-lg object-contain">
            <source src="<?php echo e(asset($videos[0] ?? '')); ?>" type="video/webm">
            Votre navigateur ne supporte pas la vidéo.
        </video>
    </div>
</div>




                </div>
            <?php endif; ?>

            
            <?php if(!empty($figmaImages)): ?>
                <div x-data="{ openGallery: false, index: 0, images: <?php echo e(json_encode(array_map(fn($img) => asset($img), $figmaImages))); ?> }">
                    <button type="button" @click="openGallery = true"
                        class="inline-flex items-center gap-2 text-xs md:text-sm px-3 py-2 rounded-xl border hover:bg-gray-50">
                        Maquettes
                    </button>

                    <!-- Modale Lightbox -->
                    <div x-show="openGallery" x-transition
                        class="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 px-2"
                        style="display:none" role="dialog" aria-modal="true" aria-label="Visionneuse de maquettes">

                        <div class="relative w-full h-full flex items-center justify-center">
                            <!-- Bouton fermer -->
                            <button @click="openGallery = false"
                                class="absolute top-4 right-4 bg-white rounded-full p-2 shadow hover:bg-gray-200 z-50"
                                aria-label="Fermer la visionneuse">
                                ✖
                            </button>

                            <!-- Bouton précédent -->
                            <button @click="if (index > 0) { index-- }"
                                class="absolute left-2 sm:left-6 top-1/2 transform -translate-y-1/2
                                       bg-white/80 text-black rounded-full p-3 shadow hover:bg-white
                                       disabled:opacity-40 disabled:cursor-not-allowed z-50"
                                :disabled="index === 0" aria-label="Maquette précédente">
                                ⬅
                            </button>

                            <!-- Image principale -->
                            <figure class="max-h-[90vh] max-w-full flex items-center justify-center relative"
                                role="group" aria-labelledby="caption-lightbox">
                                <img :src="images[index]" :alt="'Maquette ' + (index + 1)"
                                    class="max-h-[90vh] max-w-full object-contain rounded-lg shadow-lg" loading="lazy">
                                <figcaption id="caption-lightbox" class="sr-only">
                                    Maquette du projet sélectionné
                                </figcaption>
                            </figure>

                            <!-- Bouton suivant -->
                            <button @click="if (index < images.length - 1) { index++ }"
                                class="absolute right-2 sm:right-6 top-1/2 transform -translate-y-1/2
                                       bg-white/80 text-black rounded-full p-3 shadow hover:bg-white
                                       disabled:opacity-40 disabled:cursor-not-allowed z-50"
                                :disabled="index === images.length - 1" aria-label="Maquette suivante">
                                ➡
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</article>
<?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/components/project-card.blade.php ENDPATH**/ ?>