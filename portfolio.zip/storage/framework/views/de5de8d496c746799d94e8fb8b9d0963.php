<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo $__env->yieldContent('title', 'Tableau de bord admin'); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>
<body class="bg-gray-50" x-data="{ open:false }" x-cloak>
  <div class="min-h-screen md:flex">

    
    <div 
      class="fixed inset-0 bg-black/40 z-30 md:hidden"
      x-show="open"
      x-transition.opacity
      @click="open=false"
      aria-hidden="true">
    </div>

    
    <aside
      class="fixed inset-y-0 left-0 z-40 w-72 bg-white border-r shadow-sm
             transform -translate-x-full md:translate-x-0 md:static md:w-64
             transition-transform duration-200 ease-in-out"
      :class="{ 'translate-x-0': open }"
      role="navigation"
      aria-label="Menu d’administration"
    >
      <div class="p-4 flex items-center justify-between border-b">
        <div class="font-bold">Espace Admin</div>
        <button class="md:hidden p-2 rounded hover:bg-gray-100" 
                @click="open=false" aria-label="Fermer le menu">✖</button>
      </div>

      <?php
        $isActive = fn($pattern) => request()->routeIs($pattern) ? 'bg-gray-100 text-gray-900' : 'text-gray-700';
        $baseLink = 'block px-3 py-2 rounded hover:bg-gray-100 transition';
      ?>

      <nav class="px-2 py-3 space-y-1">
        <a href="<?php echo e(route('admin.dashboard')); ?>" 
           class="<?php echo e($baseLink); ?> <?php echo e($isActive('admin.dashboard')); ?>"
           @click="open=false">📊 Dashboard</a>

        <a href="<?php echo e(route('admin.projets.index')); ?>" 
           class="<?php echo e($baseLink); ?> <?php echo e($isActive('admin.projets.*')); ?>"
           @click="open=false">📂 Projets</a>

        <a href="<?php echo e(route('admin.users.index')); ?>" 
           class="<?php echo e($baseLink); ?> <?php echo e($isActive('admin.users.*')); ?>"
           @click="open=false">👥 Visiteurs</a>

        <a href="<?php echo e(route('admin.contacts.index')); ?>" 
           class="<?php echo e($baseLink); ?> <?php echo e($isActive('admin.contacts.*')); ?>"
           @click="open=false">✉️ Messages</a>

        <div class="pt-2 mt-2 border-t">
          <a href="<?php echo e(route('accueil')); ?>" 
             class="<?php echo e($baseLink); ?>" 
             @click="open=false">🏠 Accueil public</a>
        </div>

        <div class="pt-2 mt-2 border-t">
          <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" 
              class="w-full text-left <?php echo e($baseLink); ?> text-red-600 hover:bg-red-50"
              @click="open=false">
              🚪 Déconnexion
            </button>
          </form>
        </div>
      </nav>
    </aside>

    
    <main class="flex-1">
      
      <div class="md:hidden p-3">
        <button class="inline-flex items-center gap-2 px-3 py-2 rounded border bg-white hover:bg-gray-50"
                @click="open=true"
                aria-label="Ouvrir le menu">
          ☰ <span class="text-sm">Menu</span>
        </button>
      </div>

      <?php echo $__env->yieldContent('content'); ?>
    </main>
  </div>

  <script src="https://unpkg.com/alpinejs" defer></script>
</body>
</html>
<?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/layouts/admin.blade.php ENDPATH**/ ?>