

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-6">🗑️ Messages supprimés</h1>

    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white rounded-xl shadow-md hover:shadow-lg transition p-4 flex flex-col justify-between">
                <!-- Sujet + Date -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 mb-2">
                        <?php echo e($message->subject); ?>

                    </h2>
                    <p class="text-sm text-gray-500">
                        Supprimé le <?php echo e($message->deleted_at->format('d/m/Y H:i')); ?>

                    </p>
                </div>

                <!-- Actions -->
                <div class="mt-4 flex justify-between">
                    <!-- Restaurer -->
                    <form action="<?php echo e(route('messages.restore', $message->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" 
                                class="inline-flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition">
                            ♻️ Restaurer
                        </button>
                    </form>

                    <!-- Supprimer définitivement -->
                    <form action="<?php echo e(route('messages.forceDelete', $message->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" 
                                class="inline-flex items-center px-3 py-1 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition">
                            ❌ Supprimer
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500 col-span-full text-center">Aucun message supprimé.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/user/messages/deleted.blade.php ENDPATH**/ ?>