
<?php if(session('success')): ?>
    <div class="mb-4 p-3 rounded bg-green-100 text-green-800 border border-green-300">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>


<?php $__env->startSection('title', 'Détail message'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-3xl mx-auto">
        <div class="bg-white shadow rounded-lg p-6">
            <h1 class="text-2xl font-bold mb-4">📩 Message de <?php echo e($message->name); ?></h1>

            <p><strong>Email :</strong> <?php echo e($message->email); ?></p>
            <p><strong>Sujet :</strong> <?php echo e($message->subject ?? '—'); ?></p>
            <p><strong>Date :</strong> <?php echo e($message->created_at->format('d/m/Y H:i')); ?></p>

            <hr class="my-4">

            <div class="prose">
                <?php echo nl2br(e($message->message)); ?>

            </div>

            <hr class="my-6">

            
            <h2 class="text-xl font-semibold mb-2">Répondre à <?php echo e($message->name); ?></h2>
            <form method="POST" action="<?php echo e(route('admin.contacts.reply', $message->id)); ?>">
                <?php echo csrf_field(); ?>
                <textarea name="reply" rows="4" class="w-full border rounded p-2 mb-3" required></textarea>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                    ✉️ Envoyer la réponse
                </button>
            </form>

            <div class="flex justify-between mt-6">
                <a href="<?php echo e(route('admin.contacts.index')); ?>" class="text-gray-600 hover:underline">
                    ← Retour aux messages
                </a>
                <form action="<?php echo e(route('admin.contacts.destroy', $message->id)); ?>" method="POST"
                      onsubmit="return confirm('Supprimer définitivement ce message ?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="text-red-600 hover:underline">Supprimer</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/admin/contacts/show.blade.php ENDPATH**/ ?>