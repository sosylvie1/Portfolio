

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-6">📨 Message</h1>

    <div class="bg-white rounded-xl shadow-md p-6 max-w-2xl mx-auto">
        <!-- Infos -->
        <div class="mb-4">
            <p class="text-lg font-semibold mb-2">Objet : <span class="text-gray-800"><?php echo e($message->subject); ?></span></p>
            <p class="text-sm text-gray-600">
                <strong>De :</strong> <?php echo e($message->name); ?> <br>
                <strong>Date :</strong> <?php echo e($message->created_at->format('d/m/Y H:i')); ?>

            </p>
        </div>

        <!-- Contenu -->
        <div class="border-t border-gray-200 pt-4 mb-6">
            <p class="text-gray-700 whitespace-pre-line"><?php echo e($message->message ?? '— Aucun contenu —'); ?></p>
        </div>

        <div class="flex justify-between items-center">
            <!-- Retour -->
            <a href="<?php echo e(url()->previous()); ?>"
               class="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition">
                ⬅ Retour
            </a>

            <!-- Si reçu → bouton répondre -->
            <?php if($message->recipient_id === Auth::id()): ?>
                <form action="<?php echo e(route('messages.reply', $message->id)); ?>" method="POST" class="flex gap-2">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="reply" placeholder="Votre réponse..."
                           class="border rounded p-2 text-sm w-64" required>
                    <button type="submit"
                            class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                        📧 Répondre
                    </button>
                </form>
            <?php endif; ?>

            <!-- Si supprimé → options restauration/suppression -->
            <?php if($message->trashed()): ?>
                <div class="flex gap-2">
                    <form action="<?php echo e(route('messages.restore', $message->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="px-3 py-1 bg-green-100 text-green-700 rounded-lg hover:bg-green-200">
                            ♻ Restaurer
                        </button>
                    </form>
                    <form action="<?php echo e(route('messages.forceDelete', $message->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="px-3 py-1 bg-red-100 text-red-600 rounded-lg hover:bg-red-200">
                            ❌ Supprimer définitivement
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <!-- Suppression normale -->
                <form action="<?php echo e(route('messages.destroy', $message->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="px-3 py-1 bg-red-500 text-white rounded-lg hover:bg-red-600">
                        🗑 Supprimer
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/user/messages/show.blade.php ENDPATH**/ ?>