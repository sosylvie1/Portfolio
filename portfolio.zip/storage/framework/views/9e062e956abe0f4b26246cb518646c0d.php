<?php $__env->startComponent('mail::message'); ?>
# Bonjour <?php echo new \Illuminate\Support\EncodedHtmlString($originalMessage->name); ?>,

Vous avez reçu une réponse de l’administrateur :

---

<?php echo new \Illuminate\Support\EncodedHtmlString($reply); ?>


---

Merci de nous avoir contacté.  
Cordialement,  
**Sylvie Seguinaud – Portfolio**

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/emails/contact/reply.blade.php ENDPATH**/ ?>