

<?php $__env->startSection('title', 'Messages reçus'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-6">📥 Messages reçus</h1>

    
    <?php if(session('success')): ?>
        <div class="mb-4 p-3 rounded bg-green-100 text-green-800 border border-green-300">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($messages->isEmpty()): ?>
        <p class="text-gray-600">Aucun message pour l’instant.</p>
    <?php else: ?>
        <div class="overflow-x-auto bg-white shadow rounded-lg">
            <table class="min-w-full border border-gray-200 text-sm">
                <thead class="bg-gray-100 border-b text-gray-700">
                    <tr>
                        <th class="px-4 py-2 text-left">De</th>
                        <th class="px-4 py-2 text-left">Sujet</th>
                        <th class="px-4 py-2 text-left">Date</th>
                        <th class="px-4 py-2 text-left">Lu ?</th>
                        <th class="px-4 py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b hover:bg-gray-50 <?php echo e($msg->is_read ? '' : 'bg-pink-50'); ?>">
                            <td class="px-4 py-2"><?php echo e($msg->name); ?> (<?php echo e($msg->email); ?>)</td>
                            <td class="px-4 py-2"><?php echo e($msg->subject ?? '—'); ?></td>
                            <td class="px-4 py-2"><?php echo e($msg->created_at->format('d/m/Y H:i')); ?></td>
                            <td class="px-4 py-2">
                                <?php echo e($msg->is_read ? '✅' : '❌'); ?>

                            </td>
                            <td class="px-4 py-2 flex gap-2">

                                
                                <a href="<?php echo e(route('admin.contacts.show', $msg->id)); ?>"
                                   class="text-blue-600 hover:underline">Voir</a>

                                
                                <form action="<?php echo e(route('admin.contacts.mark', $msg->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="text-green-600 hover:underline">
                                        <?php echo e($msg->is_read ? 'Marquer non lu' : 'Marquer lu'); ?>

                                    </button>
                                </form>

                                
                                <form action="<?php echo e(route('admin.contacts.destroy', $msg->id)); ?>" method="POST"
                                      onsubmit="return confirm('Supprimer définitivement ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="text-red-600 hover:underline">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <?php echo e($messages->links()); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>