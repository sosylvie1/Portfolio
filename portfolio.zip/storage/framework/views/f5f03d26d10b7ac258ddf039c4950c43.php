<?php $__env->startSection('content'); ?>
<?php $__env->startSection('robots', 'noindex, nofollow'); ?>
<?php
  $totalProjects  = $totalProjects  ?? 0;
  $totalUsers     = $totalUsers     ?? 0;
  $totalMessages  = $totalMessages  ?? 0;

  $latestProjects = $latestProjects ?? collect();
  $latestUsers    = $latestUsers    ?? collect();
  $latestMessages = $latestMessages ?? collect();
?>

<div class="px-4 md:px-8 py-6">
  <h1 class="text-2xl font-bold mb-6">Dashboard Admin</h1>

  
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
    <a href="<?php echo e(route('admin.projets.index')); ?>" class="block p-5 rounded-2xl border bg-white shadow hover:shadow-md transition">
      <div class="text-sm text-gray-500">Projets</div>
      <div class="text-3xl font-semibold"><?php echo e($totalProjects); ?></div>
      <div class="mt-2 text-xs text-gray-400">Voir tous les projets →</div>
    </a>

    <a href="<?php echo e(route('admin.users.index')); ?>" class="block p-5 rounded-2xl border bg-white shadow hover:shadow-md transition">
      <div class="text-sm text-gray-500">Utilisateurs</div>
      <div class="text-3xl font-semibold"><?php echo e($totalUsers); ?></div>
      <div class="mt-2 text-xs text-gray-400">Voir tous les utilisateurs →</div>
    </a>

    <a href="<?php echo e(route('admin.contacts.index')); ?>" class="block p-5 rounded-2xl border bg-white shadow hover:shadow-md transition">
      <div class="text-sm text-gray-500">Messages</div>
      <div class="text-3xl font-semibold"><?php echo e($totalMessages); ?></div>
      <div class="mt-2 text-xs text-gray-400">Voir tous les messages →</div>
    </a>
  </div>

  
  <div class="bg-white rounded-2xl border shadow p-5 mb-8">
    <div class="flex items-center justify-between mb-4">
      <h2 class="font-semibold text-lg">Derniers projets</h2>
      <a href="<?php echo e(route('admin.projets.index')); ?>" class="text-sm text-pink-600 hover:underline">Tout voir</a>
    </div>
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead>
          <tr class="text-left text-gray-500 border-b">
            <th class="py-2 pr-4">Titre</th>
            <th class="py-2 pr-4">Créé le</th>
            <th class="py-2 pr-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $latestProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-b hover:bg-gray-50">
              <td class="py-2 pr-4 font-medium"><?php echo e($p->title); ?></td>
              <td class="py-2 pr-4 text-gray-600"><?php echo e($p->created_at?->format('d/m/Y H:i')); ?></td>
              <td class="py-2 pr-4">
                <a href="<?php echo e(route('admin.projets.edit', $p)); ?>" class="text-blue-600 hover:underline">Éditer</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="3" class="py-3 text-gray-500">Aucun projet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  
  <div class="bg-white rounded-2xl border shadow p-5 mb-8">
    <div class="flex items-center justify-between mb-4">
      <h2 class="font-semibold text-lg">Derniers messages</h2>
      <a href="<?php echo e(route('admin.contacts.index')); ?>" class="text-sm text-pink-600 hover:underline">Tout voir</a>
    </div>
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead>
          <tr class="text-left text-gray-500 border-b">
            <th class="py-2 pr-4">De</th>
            <th class="py-2 pr-4">Sujet</th>
            <th class="py-2 pr-4">Reçu le</th>
            <th class="py-2 pr-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $latestMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-b hover:bg-gray-50">
              <td class="py-2 pr-4"><?php echo e($m->name ?? $m->email); ?></td>
              <td class="py-2 pr-4"><?php echo e(\Illuminate\Support\Str::limit($m->subject ?? '-', 60)); ?></td>
              <td class="py-2 pr-4 text-gray-600"><?php echo e($m->created_at?->format('d/m/Y H:i')); ?></td>
              <td class="py-2 pr-4">
                <a href="<?php echo e(route('admin.contacts.show', $m)); ?>" class="text-blue-600 hover:underline">Voir</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4" class="py-3 text-gray-500">Aucun message.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  
  <div class="bg-white rounded-2xl border shadow p-5">
    <div class="flex items-center justify-between mb-4">
      <h2 class="font-semibold text-lg">Derniers utilisateurs</h2>
      <a href="<?php echo e(route('admin.users.index')); ?>" class="text-sm text-pink-600 hover:underline">Tout voir</a>
    </div>
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead>
          <tr class="text-left text-gray-500 border-b">
            <th class="py-2 pr-4">Nom</th>
            <th class="py-2 pr-4">Email</th>
            <th class="py-2 pr-4">Inscrit le</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $latestUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-b hover:bg-gray-50">
              <td class="py-2 pr-4 font-medium"><?php echo e($u->name); ?></td>
              <td class="py-2 pr-4"><?php echo e($u->email); ?></td>
              <td class="py-2 pr-4 text-gray-600"><?php echo e($u->created_at?->format('d/m/Y H:i')); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="3" class="py-3 text-gray-500">Aucun utilisateur.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>