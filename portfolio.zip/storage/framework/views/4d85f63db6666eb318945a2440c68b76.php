


<?php $__env->startSection('title', 'Plan du site'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto py-12 px-4">

    <h1 class="text-3xl font-bold mb-8 text-gray-800">Plan du site</h1>

    <div class="space-y-8 bg-white/80 shadow rounded-xl p-6 sm:p-8 leading-relaxed text-gray-700 border border-pink-100">

        
        <section>
            <h2 class="text-xl font-semibold mb-4 text-pink-600">Navigation principale</h2>
            <ul class="space-y-2 list-disc pl-5">
                <li><a href="<?php echo e(route('accueil')); ?>" class="text-blue-600 hover:underline">Accueil</a></li>
                <li><a href="<?php echo e(route('a-propos')); ?>" class="text-blue-600 hover:underline">À propos</a></li>
                <li><a href="<?php echo e(route('projets.index')); ?>" class="text-blue-600 hover:underline">Projets</a></li>
                <li><a href="<?php echo e(route('cv.public')); ?>" class="text-blue-600 hover:underline">CV</a></li>
                <li><a href="<?php echo e(route('contact.show')); ?>" class="text-blue-600 hover:underline">Contact</a></li>
            </ul>
        </section>

        
        <section>
            <h2 class="text-xl font-semibold mb-4 text-pink-600">Espace utilisateur</h2>
            <ul class="space-y-2 list-disc pl-5">
                <?php if(auth()->guard()->check()): ?>
                    <li><a href="<?php echo e(route('dashboard')); ?>" class="text-blue-600 hover:underline">Dashboard</a></li>
                    <li><a href="<?php echo e(route('profile.show')); ?>" class="text-blue-600 hover:underline">Mon profil</a></li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('login')); ?>" class="text-blue-600 hover:underline">Connexion</a></li>
                    <li><a href="<?php echo e(route('register')); ?>" class="text-blue-600 hover:underline">Créer un compte</a></li>
                <?php endif; ?>
            </ul>
        </section>

        
        <section>
            <h2 class="text-xl font-semibold mb-4 text-pink-600">Pages légales</h2>
            <ul class="space-y-2 list-disc pl-5">
                <li><a href="<?php echo e(route('confidentialite')); ?>" class="text-blue-600 hover:underline">Politique de confidentialité</a></li>
                <li><a href="<?php echo e(route('cgu')); ?>" class="text-blue-600 hover:underline">Conditions générales d’utilisation</a></li>
                <li><a href="<?php echo e(route('plan-du-site')); ?>" class="text-blue-600 hover:underline">Plan du site</a></li>
            </ul>
        </section>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('head'); ?>
<script type="application/ld+json">
<?php echo json_encode([
    '<?php $__contextArgs = [];
if (context()->has($__contextArgs[0])) :
if (isset($value)) { $__contextPrevious[] = $value; }
$value = context()->get($__contextArgs[0]); ?>' => 'https://schema.org',
    '@type' => 'WebPage',
    'name' => 'Plan du site - Portfolio de Sylvie Seguinaud',
    'description' => 'Plan du site portfolio de Sylvie Seguinaud pour naviguer facilement entre les pages principales.',
    'url' => url('/plan-du-site'),
    'inLanguage' => 'fr',
    'mainEntity' => [
        '@type' => 'SiteNavigationElement',
        'name' => 'Navigation principale',
        'hasPart' => [
            [
                '@type' => 'WebPage',
                'name' => 'Accueil',
                'url' => route('accueil')
            ],
            [
                '@type' => 'WebPage',
                'name' => 'À propos',
                'url' => route('a-propos')
            ],
            [
                '@type' => 'WebPage',
                'name' => 'Projets',
                'url' => route('projets.index')
            ],
            [
                '@type' => 'WebPage',
                'name' => 'CV',
                'url' => route('cv.public')
            ],
            [
                '@type' => 'WebPage',
                'name' => 'Contact',
                'url' => route('contact.show')
            ],
            [
                '@type' => 'WebPage',
                'name' => 'Politique de confidentialité',
                'url' => route('confidentialite')
            ],
            [
                '@type' => 'WebPage',
                'name' => 'Conditions générales d’utilisation',
                'url' => route('cgu')
            ],
            [
                '@type' => 'WebPage',
                'name' => 'Plan du site',
                'url' => route('plan-du-site')
            ]
        ]
    ]
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); ?>

</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/pages/plan-du-site.blade.php ENDPATH**/ ?>