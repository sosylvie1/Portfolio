<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Sylvie Seguinaud')); ?></title>

    

    <head>
        
        <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
    </head>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="font-sans text-gray-900 antialiased">
    <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100">
        


        <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
            <?php echo e($slot); ?>

        </div>
    </div>
    
    <?php if (isset($component)) { $__componentOriginal92b72694074b0734d070a343e253839a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92b72694074b0734d070a343e253839a = $attributes; } ?>
<?php $component = App\View\Components\CookieBanner::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cookie-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CookieBanner::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92b72694074b0734d070a343e253839a)): ?>
<?php $attributes = $__attributesOriginal92b72694074b0734d070a343e253839a; ?>
<?php unset($__attributesOriginal92b72694074b0734d070a343e253839a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92b72694074b0734d070a343e253839a)): ?>
<?php $component = $__componentOriginal92b72694074b0734d070a343e253839a; ?>
<?php unset($__componentOriginal92b72694074b0734d070a343e253839a); ?>
<?php endif; ?>
</body>

</html><?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/layouts/guest.blade.php ENDPATH**/ ?>