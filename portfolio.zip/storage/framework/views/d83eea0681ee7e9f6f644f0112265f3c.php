

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto p-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">📂 Mes Projets (admin)</h1>
        <a href="<?php echo e(route('admin.projets.create')); ?>"
           class="px-4 py-2 bg-pink-600 text-white rounded-lg shadow hover:bg-pink-700 transition">
            ➕ Ajouter un projet
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($projects->isEmpty()): ?>
        <p class="text-gray-600">Aucun projet pour le moment.</p>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="relative group border rounded-xl overflow-hidden shadow hover:shadow-md transition">
                    
                    <?php if (isset($component)) { $__componentOriginalb009b6bea983337cad65fcfb8a10d717 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb009b6bea983337cad65fcfb8a10d717 = $attributes; } ?>
<?php $component = App\View\Components\ProjectCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('project-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProjectCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['p' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($project)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb009b6bea983337cad65fcfb8a10d717)): ?>
<?php $attributes = $__attributesOriginalb009b6bea983337cad65fcfb8a10d717; ?>
<?php unset($__attributesOriginalb009b6bea983337cad65fcfb8a10d717); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb009b6bea983337cad65fcfb8a10d717)): ?>
<?php $component = $__componentOriginalb009b6bea983337cad65fcfb8a10d717; ?>
<?php unset($__componentOriginalb009b6bea983337cad65fcfb8a10d717); ?>
<?php endif; ?>

                    
                    <div class="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition">
                        
                        <a href="<?php echo e(route('admin.projets.edit', $project->id)); ?>"
                           class="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600">
                            ✏️ Modifier
                        </a>

                        
                        <form action="<?php echo e(route('admin.projets.destroy', $project->id)); ?>"
                              method="POST"
                              onsubmit="return confirm('Supprimer ce projet ?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                    class="px-3 py-1 bg-red-500 text-white text-sm rounded hover:bg-red-600">
                                🗑️ Supprimer
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Utilisateur\Desktop\portfolio\resources\views/admin/projets/index.blade.php ENDPATH**/ ?>